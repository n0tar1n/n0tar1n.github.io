"""Filtering and stack operations used throughout the project."""

from __future__ import annotations

import numpy as np
import cv2
from scipy.signal import convolve2d


def convolve_four_loops(image: np.ndarray, kernel: np.ndarray) -> np.ndarray:
    """Compute a zero-padded same-size 2D convolution using four loops."""
    if image.ndim != 2 or kernel.ndim != 2:
        raise ValueError("convolve_four_loops expects two 2D arrays.")
    kh, kw = kernel.shape
    pad_y, pad_x = kh // 2, kw // 2
    padded = np.pad(image, ((pad_y, pad_y), (pad_x, pad_x)), mode="constant")
    flipped = kernel[::-1, ::-1]
    result = np.zeros_like(image, dtype=np.float64)
    for y in range(image.shape[0]):
        for x in range(image.shape[1]):
            for ky in range(kh):
                for kx in range(kw):
                    result[y, x] += padded[y + ky, x + kx] * flipped[ky, kx]
    return result


def convolve_two_loops(image: np.ndarray, kernel: np.ndarray) -> np.ndarray:
    """Compute a zero-padded same-size 2D convolution using two loops."""
    if image.ndim != 2 or kernel.ndim != 2:
        raise ValueError("convolve_two_loops expects two 2D arrays.")
    kh, kw = kernel.shape
    pad_y, pad_x = kh // 2, kw // 2
    padded = np.pad(image, ((pad_y, pad_y), (pad_x, pad_x)), mode="constant")
    flipped = kernel[::-1, ::-1]
    result = np.zeros_like(image, dtype=np.float64)
    for y in range(image.shape[0]):
        for x in range(image.shape[1]):
            result[y, x] = np.sum(padded[y : y + kh, x : x + kw] * flipped)
    return result


def convolve_channels(image: np.ndarray, kernel: np.ndarray) -> np.ndarray:
    """Apply a same-size, zero-filled convolution to grayscale or RGB data."""
    if image.ndim == 2:
        return convolve2d(image, kernel, mode="same", boundary="fill", fillvalue=0)
    return np.dstack(
        [convolve2d(image[..., channel], kernel, mode="same", boundary="fill", fillvalue=0)
         for channel in range(image.shape[2])]
    )


def gaussian_kernel(size: int, sigma: float) -> np.ndarray:
    """Create a normalized 2D Gaussian kernel from OpenCV's 1D kernel."""
    if size % 2 == 0 or size < 3:
        raise ValueError("Gaussian kernel size must be an odd integer of at least 3.")
    vector = cv2.getGaussianKernel(size, sigma)
    return vector @ vector.T


def high_pass(image: np.ndarray, kernel: np.ndarray) -> np.ndarray:
    """Return the high-frequency residual defined by a Gaussian kernel."""
    return image - convolve_channels(image, kernel)


def unsharp_kernel(blur_kernel: np.ndarray, amount: float) -> np.ndarray:
    """Create the single convolution kernel for unsharp masking."""
    impulse = np.zeros_like(blur_kernel)
    impulse[blur_kernel.shape[0] // 2, blur_kernel.shape[1] // 2] = 1.0
    return (1.0 + amount) * impulse - amount * blur_kernel


def unsharp_mask(image: np.ndarray, kernel: np.ndarray, amount: float) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return low frequencies, high frequencies, and an unsharp-masked image."""
    low = convolve_channels(image, kernel)
    high = image - low
    sharpened = convolve_channels(image, unsharp_kernel(kernel, amount))
    return low, high, np.clip(sharpened, 0.0, 1.0)


def gaussian_stack(
    image: np.ndarray, levels: int, kernel: np.ndarray, initial_blur_passes: int = 0,
) -> list[np.ndarray]:
    """Build a same-resolution Gaussian stack without using pyramid helpers."""
    first_level = image.astype(np.float64)
    if initial_blur_passes < 0:
        raise ValueError("initial_blur_passes must be non-negative.")
    for _ in range(initial_blur_passes):
        first_level = cv2.filter2D(first_level, ddepth=-1, kernel=kernel, borderType=cv2.BORDER_REFLECT_101)
    stack = [first_level]
    for _ in range(1, levels):
        stack.append(cv2.filter2D(stack[-1], ddepth=-1, kernel=kernel, borderType=cv2.BORDER_REFLECT_101))
    return stack


def laplacian_stack(image: np.ndarray, levels: int, kernel: np.ndarray) -> list[np.ndarray]:
    """Build a same-resolution Laplacian stack whose levels reconstruct the input."""
    gaussians = gaussian_stack(image, levels, kernel)
    return [gaussians[index] - gaussians[index + 1] for index in range(levels - 1)] + [gaussians[-1]]


def reconstruct_laplacian(levels: list[np.ndarray]) -> np.ndarray:
    """Reconstruct an image by summing all Laplacian-stack levels."""
    return np.sum(np.stack(levels, axis=0), axis=0)


def multiresolution_blend(
    image_a: np.ndarray, image_b: np.ndarray, mask: np.ndarray, levels: int, kernel: np.ndarray,
    mask_kernel: np.ndarray | None = None, mask_initial_blur_passes: int = 0,
) -> tuple[np.ndarray, list[np.ndarray], list[np.ndarray], list[np.ndarray]]:
    """Blend two matched images with Laplacian images and a Gaussian mask stack."""
    if image_a.shape != image_b.shape:
        raise ValueError("Images must have identical dimensions before blending.")
    if mask.shape != image_a.shape[:2]:
        raise ValueError("Mask must match the image height and width.")
    lap_a = laplacian_stack(image_a, levels, kernel)
    lap_b = laplacian_stack(image_b, levels, kernel)
    mask_stack = gaussian_stack(
        mask, levels, kernel if mask_kernel is None else mask_kernel,
        initial_blur_passes=mask_initial_blur_passes,
    )
    blended_levels = []
    for a_level, b_level, mask_level in zip(lap_a, lap_b, mask_stack):
        expanded_mask = mask_level[..., None] if a_level.ndim == 3 else mask_level
        blended_levels.append(expanded_mask * a_level + (1.0 - expanded_mask) * b_level)
    return np.clip(reconstruct_laplacian(blended_levels), 0.0, 1.0), lap_a, lap_b, mask_stack
