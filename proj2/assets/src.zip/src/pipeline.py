"""Generation of the visual results required by the assignment."""

from __future__ import annotations

from pathlib import Path
from time import perf_counter
import argparse
import numpy as np
import matplotlib.pyplot as plt
import cv2
from matplotlib.colors import hsv_to_rgb
from scipy.signal import convolve2d

from .filters import (
    convolve_four_loops, convolve_two_loops, convolve_channels, gaussian_kernel,
    high_pass, unsharp_mask, gaussian_stack, laplacian_stack, multiresolution_blend,
)
from .io_utils import load_image, save_image, save_figure, matched_pair, center_crop_to_shape, find_first_image
from .prepare_inputs import prepare_project_inputs


DX = np.array([[1.0, -1.0]])
DY = np.array([[1.0], [-1.0]])


def _display(axis: plt.Axes, image: np.ndarray, title: str, cmap: str | None = None) -> None:
    axis.imshow(image, cmap=cmap, vmin=0 if cmap else None, vmax=1 if cmap else None)
    axis.set_title(title)
    axis.axis("off")


def _figure_grid(images: list[np.ndarray], titles: list[str], columns: int, path: Path, cmap: str | None = None) -> None:
    rows = int(np.ceil(len(images) / columns))
    figure, axes = plt.subplots(rows, columns, figsize=(4 * columns, 3.5 * rows))
    for axis, image, title in zip(np.ravel(axes), images, titles):
        _display(axis, image, title, cmap)
    for axis in np.ravel(axes)[len(images):]:
        axis.axis("off")
    figure.tight_layout()
    save_figure(path, figure)


def _normalize_signed(image: np.ndarray) -> np.ndarray:
    maximum = np.max(np.abs(image))
    return image / maximum / 2 + 0.5 if maximum > 0 else image


def _visualize_laplacian_band(image: np.ndarray) -> np.ndarray:
    """Display a signed Laplacian band around mid-gray without edge outliers."""
    gray = image if image.ndim == 2 else np.dot(image[..., :3], np.array([0.299, 0.587, 0.114]))
    scale = np.percentile(np.abs(gray), 99)
    return np.clip(0.5 + 0.5 * gray / scale, 0.0, 1.0) if scale > 0 else np.full_like(gray, 0.5)


def _log_spectrum(image: np.ndarray) -> np.ndarray:
    gray = image if image.ndim == 2 else np.mean(image, axis=2)
    return np.log1p(np.abs(np.fft.fftshift(np.fft.fft2(gray))))


def _grayscale_rgb(image: np.ndarray) -> np.ndarray:
    """Convert an RGB image to three identical luminance channels for comparison views."""
    gray = image if image.ndim == 2 else np.dot(image[..., :3], np.array([0.299, 0.587, 0.114]))
    return np.repeat(gray[..., None], 3, axis=2)


def run_convolution_demo(portrait_path: Path, output: Path) -> None:
    """Compare both required handmade convolutions against SciPy on a portrait."""
    portrait = load_image(portrait_path, grayscale=True, max_dimension=260)
    box = np.ones((9, 9), dtype=np.float64) / 81.0
    timings: dict[str, float] = {}
    results: dict[str, np.ndarray] = {}
    for name, function in [("four loops", convolve_four_loops), ("two loops", convolve_two_loops)]:
        start = perf_counter()
        results[name] = function(portrait, box)
        timings[name] = perf_counter() - start
    start = perf_counter()
    scipy_box = convolve2d(portrait, box, mode="same", boundary="fill", fillvalue=0)
    timings["SciPy"] = perf_counter() - start
    max_errors = {name: np.max(np.abs(value - scipy_box)) for name, value in results.items()}
    derivatives = [convolve_two_loops(portrait, DX), convolve_two_loops(portrait, DY)]
    _figure_grid(
        [portrait, results["four loops"], results["two loops"], scipy_box, *map(_normalize_signed, derivatives)],
        [
            "Portrait (grayscale)", "9×9 box: four loops", "9×9 box: two loops",
            "9×9 box: scipy.signal.convolve2d", "Dₓ convolution", "Dᵧ convolution",
        ],
        3, output / "part1" / "convolution_comparison.png", "gray",
    )
    report = output / "part1" / "convolution_measurements.txt"
    report.write_text(
        "Convolution implementation check\n"
        f"Four-loop runtime: {timings['four loops']:.6f} s\n"
        f"Two-loop runtime: {timings['two loops']:.6f} s\n"
        f"SciPy runtime: {timings['SciPy']:.6f} s\n"
        f"Four-loop maximum absolute error vs SciPy: {max_errors['four loops']:.3e}\n"
        f"Two-loop maximum absolute error vs SciPy: {max_errors['two loops']:.3e}\n"
        "All methods use zero-filled same-size padding.\n"
    )


def _orientation_hsv(dx: np.ndarray, dy: np.ndarray) -> np.ndarray:
    """Visualize gradient direction as hue and strength as HSV saturation/value."""
    safe_dx = np.where(np.abs(dx) < 1e-12, 1e-12, dx)
    angle = np.arctan(dy / safe_dx)
    angle += np.where(dx < 0, np.pi, 0.0)
    angle = np.where((dx >= 0) & (dy < 0), angle + 2 * np.pi, angle)
    hue = (angle % (2 * np.pi)) / (2 * np.pi)
    magnitude = np.hypot(dx, dy)
    scale = np.percentile(magnitude, 99)
    strength = np.clip(magnitude / scale, 0.0, 1.0) if scale > 0 else magnitude
    hsv = np.dstack((hue, strength, strength))
    return hsv_to_rgb(hsv)


def run_edges(
    cameraman_path: Path, output: Path, raw_threshold: float, smooth_threshold: float,
    sigma: float, dog_threshold: float,
) -> None:
    """Create finite-difference, Gaussian-smoothed, and DoG edge results."""
    image = load_image(cameraman_path, grayscale=True)
    raw_x, raw_y = convolve_channels(image, DX), convolve_channels(image, DY)
    raw_magnitude = np.hypot(raw_x, raw_y)
    kernel = gaussian_kernel(25, sigma)
    blurred = convolve_channels(image, kernel)
    smooth_x, smooth_y = convolve_channels(blurred, DX), convolve_channels(blurred, DY)
    smooth_magnitude = np.hypot(smooth_x, smooth_y)
    dog_x, dog_y = convolve2d(kernel, DX, mode="full"), convolve2d(kernel, DY, mode="full")
    dog_response_x = convolve_channels(image, dog_x)
    dog_response_y = convolve_channels(image, dog_y)
    dog_magnitude = np.hypot(dog_response_x, dog_response_y)
    orientation = _orientation_hsv(dog_response_x, dog_response_y)
    difference = np.hypot(smooth_x - dog_response_x, smooth_y - dog_response_y)
    interior = difference[13:-13, 13:-13]
    verification = output / "part1" / "dog_verification.txt"
    verification.write_text(
        "Derivative-of-Gaussian verification\n"
        f"Maximum interior gradient-vector difference: {np.max(interior):.3e}\n"
        "A one-pixel derivative and a 25x25 Gaussian leave a 13-pixel boundary region where "
        "sequential zero padding and one-pass zero padding differ.\n"
    )
    _figure_grid(
        [_normalize_signed(raw_x), _normalize_signed(raw_y), raw_magnitude, raw_magnitude > raw_threshold,
         blurred, _normalize_signed(smooth_x), _normalize_signed(smooth_y), smooth_magnitude,
         smooth_magnitude > smooth_threshold],
        ["Finite difference Dₓ (signed)", "Finite difference Dᵧ (signed)", "Raw gradient magnitude", f"Raw edges (threshold={raw_threshold})",
         "Gaussian-smoothed image", "Smoothed Dₓ (signed)", "Smoothed Dᵧ (signed)", "Smoothed gradient magnitude",
         f"Smoothed edges (threshold={smooth_threshold})"],
        3, output / "part1" / "edge_detection.png", "gray",
    )
    _figure_grid(
        [_grayscale_rgb(_normalize_signed(dog_x)), _grayscale_rgb(_normalize_signed(dog_y)), _grayscale_rgb(dog_magnitude),
         _grayscale_rgb(dog_magnitude > dog_threshold), orientation, _grayscale_rgb(difference)],
        ["Derivative-of-Gaussian Dₓ (signed)", "Derivative-of-Gaussian Dᵧ (signed)", "DoG gradient magnitude",
         f"DoG edges (threshold={dog_threshold})", "Gradient orientation (HSV)", "DoG vs. smoothed-gradient difference"],
        3, output / "part1" / "dog_and_orientation.png", None,
    )
    save_image(output / "part1" / "dog_edges.png", dog_magnitude > dog_threshold)


def run_sharpening(image_path: Path, output: Path, name: str, sigma: float = 2.0, evaluate_recovery: bool = False) -> None:
    """Create unsharp-mask views for several sharpening amounts."""
    image = load_image(image_path)
    kernel = gaussian_kernel(25, sigma)
    low, high, sharpened = unsharp_mask(image, kernel, amount=1.5)
    variants = [unsharp_mask(image, kernel, amount=value)[2] for value in (0.5, 1.0, 2.0)]
    recovery_images: list[np.ndarray] = []
    recovery_titles: list[str] = []
    if evaluate_recovery:
        deliberately_blurred = convolve_channels(image, kernel)
        recovered = unsharp_mask(deliberately_blurred, kernel, amount=2.0)[2]
        recovery_images = [deliberately_blurred, recovered]
        recovery_titles = ["Deliberately blurred sharp image", "Blurred then sharpened (amount=2.0)"]
    _figure_grid(
        [image, low, _normalize_signed(high), sharpened, *variants, *recovery_images],
        ["Original", "Low frequencies (blur)", "High-frequency residual", "Sharpened (amount=1.5)", "Amount=0.5", "Amount=1.0", "Amount=2.0", *recovery_titles],
        4, output / "part2" / f"sharpening_{name}.png", None,
    )
    save_image(output / "part2" / f"sharpened_{name}.png", sharpened)


def run_hybrid(
    low_path: Path, high_path: Path, output: Path, name: str, low_sigma: float, high_sigma: float,
    detailed: bool, color_comparison: bool = False, high_validity_path: Path | None = None,
    original_high_path: Path | None = None,
) -> None:
    """Combine low frequencies from one image with high frequencies from another."""
    low_image, high_image = matched_pair(load_image(low_path), load_image(high_path))
    high_validity = None
    if high_validity_path is not None:
        high_validity = center_crop_to_shape(load_image(high_validity_path, grayscale=True), *low_image.shape[:2])
        high_validity = cv2.erode(
            (high_validity * 255).astype(np.uint8), np.ones((41, 41), dtype=np.uint8), iterations=1,
        ).astype(np.float64) / 255.0
    low_filtered = convolve_channels(low_image, gaussian_kernel(31, low_sigma))
    high_filtered = high_pass(high_image, gaussian_kernel(31, high_sigma))
    if high_validity is not None:
        high_filtered *= high_validity[..., None]
    hybrid = np.clip(low_filtered + high_filtered, 0.0, 1.0)
    save_image(output / "part2" / f"hybrid_{name}.png", hybrid)
    if detailed:
        original_high = load_image(original_high_path) if original_high_path is not None else high_image
        _figure_grid(
            [low_image, original_high, high_image, _log_spectrum(low_image), _log_spectrum(high_image), low_filtered,
             _normalize_signed(high_filtered), _log_spectrum(low_filtered), _log_spectrum(high_filtered), hybrid,
             _log_spectrum(hybrid)],
            [f"Low-pass source (σ={low_sigma:g})", "Original high-pass source", "Aligned high-pass source",
             "Low source: log Fourier magnitude", "Aligned high source: log Fourier magnitude",
             f"Low-pass filtered (σ={low_sigma:g})", f"High-pass filtered (σ={high_sigma:g})",
             "Low-pass: log Fourier magnitude", "High-pass: log Fourier magnitude", "Hybrid", "Hybrid: log Fourier magnitude"],
            4, output / "part2" / f"hybrid_{name}_process.png", None,
        )
    else:
        _figure_grid(
            [low_image, high_image, hybrid], ["Low-pass source", "High-pass source", "Hybrid"],
            3, output / "part2" / f"hybrid_{name}_overview.png", None,
        )
    if color_comparison:
        low_gray, high_gray = _grayscale_rgb(low_image), _grayscale_rgb(high_image)
        high_gray_filtered = high_pass(high_gray, gaussian_kernel(31, high_sigma))
        if high_validity is not None:
            high_gray_filtered *= high_validity[..., None]
        combinations = [
            np.clip(convolve_channels(low_gray, gaussian_kernel(31, low_sigma)) + high_gray_filtered, 0.0, 1.0),
            np.clip(low_filtered + high_gray_filtered, 0.0, 1.0),
            np.clip(convolve_channels(low_gray, gaussian_kernel(31, low_sigma)) + high_filtered, 0.0, 1.0),
            hybrid,
        ]
        _figure_grid(
            combinations,
            ["Both components grayscale", "Color low frequencies only", "Color high frequencies only", "Both components color"],
            2, output / "part2" / f"hybrid_{name}_color_comparison.png", None,
        )


def _save_stack_visualization(
    image: np.ndarray, output: Path, name: str, levels: int, kernel: np.ndarray,
) -> None:
    gaussians = gaussian_stack(image, levels, kernel)
    laplacians = laplacian_stack(image, levels, kernel)
    visual_laplacians = [_visualize_laplacian_band(level) for level in laplacians[:-1]] + [laplacians[-1]]
    _figure_grid(gaussians, [f"Gaussian level {index}" for index in range(levels)], levels, output / "part2" / f"gaussian_stack_{name}.png", None)
    _figure_grid(
        visual_laplacians,
        [f"Laplacian band {index}" for index in range(levels - 1)] + ["Low-frequency residual"],
        levels, output / "part2" / f"laplacian_stack_{name}.png", "gray",
    )


def _save_blend_contribution_visualization(
    lap_a: list[np.ndarray], lap_b: list[np.ndarray], mask_stack: list[np.ndarray], path: Path,
    left_label: str, right_label: str,
) -> None:
    """Recreate the selected-band Apple/Orange/combined layout from Figure 3.42."""
    selected_levels = tuple(index for index in (0, 2, 4) if index < len(lap_a))
    figure, axes = plt.subplots(len(selected_levels) + 1, 3, figsize=(11, 13.6))
    contributions: list[tuple[np.ndarray, np.ndarray, np.ndarray]] = []
    for a_level, b_level, mask_level in zip(lap_a, lap_b, mask_stack):
        expanded_mask = mask_level[..., None] if a_level.ndim == 3 else mask_level
        apple_contribution = expanded_mask * a_level
        orange_contribution = (1.0 - expanded_mask) * b_level
        combined_contribution = apple_contribution + orange_contribution
        contributions.append((apple_contribution, orange_contribution, combined_contribution))

    band_names = {
        0: "high frequencies (level 0)",
        2: "medium frequencies (level 2)",
        4: "low frequencies (level 4)",
    }
    for row, index in enumerate(selected_levels):
        displays = [_visualize_laplacian_band(image) for image in contributions[index]]
        level_name = band_names.get(index, f"frequencies (level {index})")
        for axis, image, source in zip(axes[row], displays, (left_label, right_label, "Combined")):
            axis.imshow(image, cmap="gray", vmin=0.0, vmax=1.0)
            axis.set_title(f"{source}\n{level_name}")
            axis.axis("off")

    reconstructed = [
        np.sum(np.stack([contribution[column] for contribution in contributions], axis=0), axis=0)
        for column in range(3)
    ]
    for axis, image, source in zip(axes[-1], reconstructed, (left_label, right_label, "Combined")):
        axis.imshow(np.clip(_grayscale_rgb(image), 0.0, 1.0), cmap="gray", vmin=0.0, vmax=1.0)
        axis.set_title(f"{source}\nreconstruction from all bands")
        axis.axis("off")
    figure.tight_layout()
    save_figure(path, figure)


def run_blend(
    left_path: Path, right_path: Path, mask_path: Path | None, output: Path, name: str,
    levels: int = 5, color_comparison: bool = False, isolate_foreground: bool = False,
) -> None:
    """Create a straight-seam or supplied-mask multiresolution blend and its stacks."""
    left, right = matched_pair(load_image(left_path), load_image(right_path))
    if mask_path is None:
        mask = np.zeros(left.shape[:2], dtype=np.float64)
        mask[:, : mask.shape[1] // 2] = 1.0
    else:
        raw_mask = load_image(mask_path, grayscale=True)
        mask = np.clip(center_crop_to_shape(raw_mask, left.shape[0], left.shape[1]), 0.0, 1.0)
    kernel = gaussian_kernel(41, 8.0)
    if isolate_foreground:
        prepared_left = mask[..., None] * left + (1.0 - mask[..., None]) * right
    else:
        prepared_left = left
    blend, lap_left, lap_right, mask_stack = multiresolution_blend(
        prepared_left, right, mask, levels, kernel,
        mask_initial_blur_passes=1,
    )
    save_image(output / "part2" / f"blend_{name}.png", blend)
    left_title = "Foreground prepared over B" if isolate_foreground else "Image A"
    _figure_grid(
        [prepared_left, right, mask, blend], [left_title, "Image B", "Mask (white selects A)", "Multiresolution blend"],
        4, output / "part2" / f"blend_{name}_overview.png", None,
    )
    _save_stack_visualization(prepared_left, output, f"{name}_a", levels, kernel)
    _save_stack_visualization(right, output, f"{name}_b", levels, kernel)
    source_labels = {
        "oraple": ("Apple", "Orange"),
        "custom_1": ("Butterfly", "Orchid"),
        "custom_2": ("Seascape A", "Seascape B"),
    }
    _save_blend_contribution_visualization(
        lap_left, lap_right, mask_stack, output / "part2" / f"blend_{name}_process.png",
        *source_labels.get(name, ("Image A", "Image B")),
    )
    if color_comparison:
        gray_left, gray_right = _grayscale_rgb(prepared_left), _grayscale_rgb(right)
        grayscale_blend, _, _, _ = multiresolution_blend(
            gray_left, gray_right, mask, levels, kernel,
            mask_initial_blur_passes=1,
        )
        _figure_grid(
            [blend, grayscale_blend], ["Color multiresolution blend", "Grayscale multiresolution blend"],
            2, output / "part2" / f"blend_{name}_color_comparison.png", None,
        )


def run_available(root: Path, output: Path) -> list[str]:
    """Run every section whose required input files are available and report omissions."""
    provided = root / "data" / "provided"
    custom = root / "data" / "custom"
    messages: list[str] = []
    cameraman = provided / "cameraman.png"
    if cameraman.exists():
        run_edges(cameraman, output, raw_threshold=0.18, smooth_threshold=0.06, sigma=2.0, dog_threshold=0.06)
        messages.append("Generated Part 1.2–1.3 edge and DoG results.")
    portrait = custom / "1.1portrait.jpg"
    if portrait.exists():
        run_convolution_demo(portrait, output)
        messages.append("Generated Part 1.1 convolution comparison.")
    else:
        messages.append("Skipped Part 1.1: add a portrait to data/custom/portrait/.")
    taj = provided / "taj.jpg"
    if taj.exists():
        run_sharpening(taj, output, "taj")
        messages.append("Generated Taj Mahal sharpening results.")
    sharp = custom / "2.1Sharpening.jpeg"
    if sharp.exists():
        run_sharpening(sharp, output, "custom", evaluate_recovery=True)
        messages.append("Generated custom sharpening results.")
    else:
        messages.append("Skipped custom sharpening: add an image to data/custom/sharpening/.")
    derek = provided / "cs180_proj2_hybrid_starter_code" / "DerekPicture.jpg"
    nutmeg = provided / "cs180_proj2_hybrid_starter_code" / "nutmeg.jpg"
    aligned_nutmeg = provided / "cs180_proj2_hybrid_starter_code" / "nutmeg_aligned.png"
    if derek.exists() and aligned_nutmeg.exists():
        run_hybrid(
            derek, aligned_nutmeg, output, "derek_nutmeg", low_sigma=7.0, high_sigma=5.0,
            detailed=True, color_comparison=True,
            high_validity_path=provided / "cs180_proj2_hybrid_starter_code" / "nutmeg_aligned_mask.png",
            original_high_path=nutmeg,
        )
        messages.append("Generated Derek + Nutmeg hybrid results.")
    for index, low, high in (
        (1, custom / "2.2hybrid_cat.png", custom / "2.2hybrid_owl_aligned.png"),
        (2, custom / "2.2hybrid_face1.png", custom / "2.2hybrid_face2_aligned.png"),
    ):
        if low.exists() and high.exists():
            run_hybrid(low, high, output, f"custom_{index}", low_sigma=7.0, high_sigma=5.0, detailed=False)
            messages.append(f"Generated custom hybrid {index}.")
        else:
            messages.append(f"Skipped custom hybrid {index}: add pair{index}_low.jpg and pair{index}_high.jpg.")
    apple, orange = provided / "spline" / "apple.jpeg", provided / "spline" / "orange.jpeg"
    if apple.exists() and orange.exists():
        run_blend(apple, orange, None, output, "oraple")
        messages.append("Generated orange–apple stack and blend results.")
    for index, left, right, mask in (
        (1, custom / "2.4blend1_butterfly.png", custom / "2.4blend1_orchid.png", custom / "2.4blend1_mask.png"),
        (2, custom / "2.4blend2A.png", custom / "2.4blend2B_aligned.png", custom / "2.4blend2_mask.png"),
    ):
        if left.exists() and right.exists() and mask.exists():
            run_blend(left, right, mask, output, f"custom_{index}", color_comparison=True)
            messages.append(f"Generated custom masked blend {index}.")
        else:
            messages.append(f"Skipped custom blend {index}: add blend{index}_a.jpg, blend{index}_b.jpg, and blend{index}_mask.png.")
    return messages


def main() -> None:
    parser = argparse.ArgumentParser(description="Run CS180 Project 2 image-processing experiments.")
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1], help="Project root directory.")
    parser.add_argument("--output", type=Path, default=None, help="Output directory; defaults to <root>/output.")
    arguments = parser.parse_args()
    output = arguments.output or arguments.root / "output"
    custom = arguments.root / "data" / "custom"
    prepare_project_inputs(arguments.root)
    for message in run_available(arguments.root, output):
        print(message)


if __name__ == "__main__":
    main()
