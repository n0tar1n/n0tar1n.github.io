"""Prepare aligned custom inputs and masks for the blending examples."""

from __future__ import annotations

from pathlib import Path
import cv2
import numpy as np


def _similarity_matrix(
    source_left: tuple[float, float], source_right: tuple[float, float],
    target_left: tuple[float, float], target_right: tuple[float, float],
) -> np.ndarray:
    """Return the scale, rotation, and translation mapping one eye pair to another."""
    source_vector = np.subtract(source_right, source_left)
    target_vector = np.subtract(target_right, target_left)
    scale = np.linalg.norm(target_vector) / np.linalg.norm(source_vector)
    source_angle = np.arctan2(source_vector[1], source_vector[0])
    target_angle = np.arctan2(target_vector[1], target_vector[0])
    angle = target_angle - source_angle
    cosine, sine = scale * np.cos(angle), scale * np.sin(angle)
    linear = np.array([[cosine, -sine], [sine, cosine]])
    translation = np.subtract(target_left, linear @ np.asarray(source_left))
    return np.column_stack((linear, translation))


def _align_image(
    source_path: Path, target_path: Path, output_path: Path,
    source_left: tuple[float, float], source_right: tuple[float, float],
    target_left: tuple[float, float], target_right: tuple[float, float],
    validity_path: Path | None = None,
) -> None:
    """Align a source face or animal to a target face using manually selected eye centers."""
    source = cv2.imread(str(source_path), cv2.IMREAD_COLOR)
    target = cv2.imread(str(target_path), cv2.IMREAD_COLOR)
    if source is None or target is None:
        raise FileNotFoundError(f"Could not read {source_path} or {target_path}.")
    matrix = _similarity_matrix(source_left, source_right, target_left, target_right)
    border_pixels = np.concatenate((source[:16, :16], source[:16, -16:], source[-16:, :16], source[-16:, -16:]))
    border_color = tuple(int(value) for value in np.median(border_pixels, axis=(0, 1)))
    aligned = cv2.warpAffine(
        source, matrix, (target.shape[1], target.shape[0]),
        flags=cv2.INTER_LANCZOS4, borderMode=cv2.BORDER_CONSTANT, borderValue=border_color,
    )
    cv2.imwrite(str(output_path), aligned)
    if validity_path is not None:
        source_validity = np.full(source.shape[:2], 255, dtype=np.uint8)
        validity = cv2.warpAffine(
            source_validity, matrix, (target.shape[1], target.shape[0]),
            flags=cv2.INTER_NEAREST, borderMode=cv2.BORDER_CONSTANT, borderValue=0,
        )
        cv2.imwrite(str(validity_path), validity)


def create_butterfly_mask(image_path: Path, output_path: Path) -> None:
    """Extract the butterfly as a binary irregular mask using foreground segmentation."""
    image = cv2.imread(str(image_path), cv2.IMREAD_COLOR)
    if image is None:
        raise FileNotFoundError(f"Could not read {image_path}.")
    labels = np.zeros(image.shape[:2], dtype=np.uint8)
    rectangle = (105, 110, 815, 700)
    background_model = np.zeros((1, 65), dtype=np.float64)
    foreground_model = np.zeros((1, 65), dtype=np.float64)
    cv2.grabCut(image, labels, rectangle, background_model, foreground_model, 8, cv2.GC_INIT_WITH_RECT)
    mask = np.where((labels == cv2.GC_FGD) | (labels == cv2.GC_PR_FGD), 255, 0).astype(np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((7, 7), dtype=np.uint8), iterations=2)
    count, components, statistics, _ = cv2.connectedComponentsWithStats(mask)
    if count > 1:
        largest = 1 + np.argmax(statistics[1:, cv2.CC_STAT_AREA])
        mask = np.where(components == largest, 255, 0).astype(np.uint8)
    outside = mask.copy()
    flood_buffer = np.zeros((mask.shape[0] + 2, mask.shape[1] + 2), dtype=np.uint8)
    cv2.floodFill(outside, flood_buffer, (0, 0), 255)
    enclosed_holes = cv2.bitwise_not(outside)
    mask = cv2.bitwise_or(mask, enclosed_holes)
    cv2.imwrite(str(output_path), mask)


def create_bird_mask(image_path: Path, seed_mask_path: Path, output_path: Path) -> None:
    """Refine a bird silhouette from a seeded foreground mask."""
    image = cv2.imread(str(image_path), cv2.IMREAD_COLOR)
    seed_mask = cv2.imread(str(seed_mask_path), cv2.IMREAD_GRAYSCALE)
    if image is None or seed_mask is None:
        raise FileNotFoundError(f"Could not read {image_path} or {seed_mask_path}.")
    seed_mask = cv2.resize(seed_mask, (image.shape[1], image.shape[0]), interpolation=cv2.INTER_NEAREST)
    seed_mask = np.where(seed_mask >= 128, 255, 0).astype(np.uint8)
    eroded = cv2.erode(seed_mask, np.ones((11, 11), dtype=np.uint8), iterations=1)
    dilated = cv2.dilate(seed_mask, np.ones((19, 19), dtype=np.uint8), iterations=1)
    labels = np.full(image.shape[:2], cv2.GC_BGD, dtype=np.uint8)
    labels[dilated > 0] = cv2.GC_PR_BGD
    labels[seed_mask > 0] = cv2.GC_PR_FGD
    labels[eroded > 0] = cv2.GC_FGD
    background_model = np.zeros((1, 65), dtype=np.float64)
    foreground_model = np.zeros((1, 65), dtype=np.float64)
    cv2.grabCut(image, labels, None, background_model, foreground_model, 10, cv2.GC_INIT_WITH_MASK)
    mask = np.where((labels == cv2.GC_FGD) | (labels == cv2.GC_PR_FGD), 255, 0).astype(np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((3, 3), dtype=np.uint8), iterations=1)
    count, components, statistics, _ = cv2.connectedComponentsWithStats(mask)
    if count > 1:
        largest = 1 + np.argmax(statistics[1:, cv2.CC_STAT_AREA])
        mask = np.where(components == largest, 255, 0).astype(np.uint8)
    outside = mask.copy()
    flood_buffer = np.zeros((mask.shape[0] + 2, mask.shape[1] + 2), dtype=np.uint8)
    cv2.floodFill(outside, flood_buffer, (0, 0), 255)
    cv2.imwrite(str(output_path), cv2.bitwise_or(mask, cv2.bitwise_not(outside)))


def create_horizon_mask(image_path: Path, output_path: Path) -> None:
    """Create a gently curved grayscale mask for blending two seascapes."""
    image = cv2.imread(str(image_path), cv2.IMREAD_COLOR)
    if image is None:
        raise FileNotFoundError(f"Could not read {image_path}.")
    height, width = image.shape[:2]
    x = np.arange(width, dtype=np.float64)
    transition = 0.52 * height + 0.045 * height * np.sin(2.0 * np.pi * x / width + 0.5)
    y = np.arange(height, dtype=np.float64)[:, None]
    mask = 1.0 / (1.0 + np.exp(-(y - transition[None, :]) / 12.0))
    cv2.imwrite(str(output_path), np.round(mask * 255).astype(np.uint8))


def create_vertical_seam_mask(image_path: Path, output_path: Path, seam_x: float) -> None:
    """Create a smooth vertical seam mask that selects image A on the left."""
    image = cv2.imread(str(image_path), cv2.IMREAD_COLOR)
    if image is None:
        raise FileNotFoundError(f"Could not read {image_path}.")
    x = np.arange(image.shape[1], dtype=np.float64)
    mask = 1.0 / (1.0 + np.exp((x - seam_x) / 30.0))
    cv2.imwrite(str(output_path), np.round(np.broadcast_to(mask, image.shape[:2]) * 255).astype(np.uint8))


def align_seascape_horizons(
    reference_path: Path, source_path: Path, output_path: Path, reference_horizon: float, source_horizon: float,
) -> None:
    """Translate a seascape vertically so its horizon matches a reference image."""
    reference = cv2.imread(str(reference_path), cv2.IMREAD_COLOR)
    source = cv2.imread(str(source_path), cv2.IMREAD_COLOR)
    if reference is None or source is None:
        raise FileNotFoundError(f"Could not read {reference_path} or {source_path}.")
    translation = np.float32([[1.0, 0.0, 0.0], [0.0, 1.0, reference_horizon - source_horizon]])
    aligned = cv2.warpAffine(
        source, translation, (reference.shape[1], reference.shape[0]),
        flags=cv2.INTER_LANCZOS4, borderMode=cv2.BORDER_REFLECT_101,
    )
    cv2.imwrite(str(output_path), aligned)


def prepare_project_inputs(root: Path) -> None:
    """Create all derived custom inputs required by the processing pipeline."""
    custom = root / "data" / "custom"
    provided = root / "data" / "provided" / "cs180_proj2_hybrid_starter_code"
    derek, nutmeg = provided / "DerekPicture.jpg", provided / "nutmeg.jpg"
    if derek.exists() and nutmeg.exists():
        _align_image(
            nutmeg, derek, provided / "nutmeg_aligned.png",
            source_left=(595, 287), source_right=(748, 369),
            target_left=(300, 345), target_right=(436, 331),
            validity_path=provided / "nutmeg_aligned_mask.png",
        )
    cat, owl = custom / "2.2hybrid_cat.png", custom / "2.2hybrid_owl.png"
    if cat.exists() and owl.exists():
        _align_image(
            owl, cat, custom / "2.2hybrid_owl_aligned.png",
            source_left=(457, 311), source_right=(626, 311),
            target_left=(374, 587), target_right=(676, 587),
        )
    face1, face2 = custom / "2.2hybrid_face1.png", custom / "2.2hybrid_face2.png"
    if face1.exists() and face2.exists():
        _align_image(
            face2, face1, custom / "2.2hybrid_face2_aligned.png",
            source_left=(324, 430), source_right=(488, 430),
            target_left=(375, 425), target_right=(611, 430),
        )
    butterfly = custom / "2.4blend1_butterfly.png"
    if butterfly.exists():
        create_butterfly_mask(butterfly, custom / "2.4blend1_mask.png")
    blend2a = custom / "2.4blend2A.png"
    blend2b = custom / "2.4blend2B.png"
    if blend2a.exists() and blend2b.exists():
        align_seascape_horizons(
            blend2a, blend2b, custom / "2.4blend2B_aligned.png",
            reference_horizon=161.0, source_horizon=244.0,
        )
        create_vertical_seam_mask(blend2a, custom / "2.4blend2_mask.png", seam_x=320.0)


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    prepare_project_inputs(root)
    print("Saved aligned hybrid inputs and blend masks in data/custom/.")


if __name__ == "__main__":
    main()
