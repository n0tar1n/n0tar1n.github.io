"""Image-processing utilities for CS180 Project 2."""
