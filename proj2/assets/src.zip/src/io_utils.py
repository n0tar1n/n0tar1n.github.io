"""Image loading, alignment, and figure-saving helpers."""

from __future__ import annotations

from pathlib import Path
import numpy as np
from PIL import Image, ImageOps
import matplotlib.pyplot as plt


IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff"}


def load_image(path: Path, grayscale: bool = False, max_dimension: int = 700) -> np.ndarray:
    """Load an image as float data in [0, 1], resizing only when it is very large."""
    image = ImageOps.exif_transpose(Image.open(path)).convert("L" if grayscale else "RGB")
    if max(image.size) > max_dimension:
        scale = max_dimension / max(image.size)
        image = image.resize((round(image.width * scale), round(image.height * scale)), Image.Resampling.LANCZOS)
    return np.asarray(image, dtype=np.float64) / 255.0


def save_image(path: Path, image: np.ndarray) -> None:
    """Save normalized image data as an 8-bit image."""
    path.parent.mkdir(parents=True, exist_ok=True)
    clipped = np.clip(image, 0.0, 1.0)
    if clipped.ndim == 2:
        Image.fromarray(np.round(clipped * 255).astype(np.uint8), mode="L").save(path)
    else:
        Image.fromarray(np.round(clipped * 255).astype(np.uint8), mode="RGB").save(path)


def save_figure(path: Path, figure: plt.Figure) -> None:
    """Save a tightly cropped figure and close it to free memory."""
    path.parent.mkdir(parents=True, exist_ok=True)
    figure.savefig(path, dpi=160, bbox_inches="tight")
    plt.close(figure)


def center_crop_to_shape(image: np.ndarray, target_height: int, target_width: int) -> np.ndarray:
    """Resize then center-crop an image to a requested shape without distortion."""
    source_height, source_width = image.shape[:2]
    scale = max(target_height / source_height, target_width / source_width)
    resized_height, resized_width = round(source_height * scale), round(source_width * scale)
    pil_mode = "L" if image.ndim == 2 else "RGB"
    uint8 = np.round(np.clip(image, 0, 1) * 255).astype(np.uint8)
    resized = np.asarray(
        Image.fromarray(uint8, mode=pil_mode).resize((resized_width, resized_height), Image.Resampling.LANCZOS),
        dtype=np.float64,
    ) / 255.0
    top = (resized_height - target_height) // 2
    left = (resized_width - target_width) // 2
    return resized[top : top + target_height, left : left + target_width]


def matched_pair(first: np.ndarray, second: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Match two images to the smaller common dimensions with center crops."""
    height = min(first.shape[0], second.shape[0])
    width = min(first.shape[1], second.shape[1])
    return center_crop_to_shape(first, height, width), center_crop_to_shape(second, height, width)


def find_first_image(directory: Path) -> Path | None:
    """Return the first supported image in a directory, if one is present."""
    candidates = sorted(path for path in directory.iterdir() if path.suffix.lower() in IMAGE_SUFFIXES)
    return candidates[0] if candidates else None
